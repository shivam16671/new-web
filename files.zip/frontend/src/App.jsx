import React from 'react';

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center">
      <header className="bg-blue-700 text-white w-full p-4 text-center text-2xl font-bold">
        CAprep – For CA Aspirants
      </header>
      <main className="flex-1 w-full max-w-3xl p-4">
        <h1 className="text-xl font-semibold mb-4">Welcome to CAprep!</h1>
        <p>
          Access study material, attempt mock tests, and join the community.
        </p>
      </main>
      <footer className="bg-gray-800 text-white p-2 w-full text-center">
        © 2025 CAprep
      </footer>
    </div>
  );
}

export default App;