const express = require('express');
const router = express.Router();
const { generateQuiz } = require('../services/quizService');

router.post('/generate', async (req, res) => {
  const { topic } = req.body;
  try {
    const quiz = await generateQuiz(topic); // Call OpenAI or your LLM API
    res.json(quiz);
  } catch (err) {
    res.status(500).json({ error: 'Quiz generation failed', details: err.message });
  }
});

module.exports = router;