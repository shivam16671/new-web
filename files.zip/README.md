# CAprep – Website For CA Aspirants

CAprep is a platform for Chartered Accountant aspirants to access study material, take mock tests, track their progress, and connect with other students.

## Features

- Curated study material
- Mock tests with results
- User progress tracking
- Community forum
- User authentication

## Tech Stack

- React.js (frontend)
- Node.js & Express.js (backend)
- MongoDB (database)

## Setup

1. Clone the repository.
2. Run `npm install` in both `frontend` and `backend` directories.
3. Start the backend: `cd backend && npm run dev`
4. Start the frontend: `cd frontend && npm run dev`

---