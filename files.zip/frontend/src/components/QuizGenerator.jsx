import React, { useState } from 'react';

export default function QuizGenerator() {
  const [topic, setTopic] = useState('');
  const [quiz, setQuiz] = useState(null);

  const handleGenerate = async () => {
    const res = await fetch('/api/quiz/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic }),
    });
    const data = await res.json();
    setQuiz(data);
  };

  return (
    <div>
      <h2>AI Quiz Generator</h2>
      <input
        type="text"
        value={topic}
        onChange={e => setTopic(e.target.value)}
        placeholder="Enter CA topic"
      />
      <button onClick={handleGenerate}>Generate Quiz</button>
      {quiz && (
        <div>
          <h3>Quiz:</h3>
          <pre>{JSON.stringify(quiz, null, 2)}</pre>
        </div>
      )}
    </div>
  );
}