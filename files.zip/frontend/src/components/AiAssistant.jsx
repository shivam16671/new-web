import React, { useState } from 'react';

export default function AiAssistant() {
  const [message, setMessage] = useState('');
  const [responses, setResponses] = useState([]);

  const handleSend = async () => {
    const res = await fetch('/api/assistant/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });
    const data = await res.json();
    setResponses([...responses, { user: message, ai: data.response }]);
    setMessage('');
  };

  return (
    <div className="ai-assistant-widget">
      <h4>Ask CAprep AI</h4>
      <div>
        {responses.map((r, i) => (
          <div key={i}>
            <b>You:</b> {r.user}<br />
            <b>AI:</b> {r.ai}<br />
          </div>
        ))}
      </div>
      <input
        type="text"
        value={message}
        onChange={e => setMessage(e.target.value)}
        placeholder="Ask a question"
      />
      <button onClick={handleSend}>Send</button>
    </div>
  );
}